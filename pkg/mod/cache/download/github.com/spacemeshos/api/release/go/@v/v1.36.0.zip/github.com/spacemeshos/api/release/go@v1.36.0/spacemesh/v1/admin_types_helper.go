package spacemeshv1

// without this export oneof is extremely ugly to use
type IsEventDetails = isEvent_Details
