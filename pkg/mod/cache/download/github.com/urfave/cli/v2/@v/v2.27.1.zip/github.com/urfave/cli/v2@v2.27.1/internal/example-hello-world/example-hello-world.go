// example hello world used for binary size checking

package main

import "fmt"

func main() {
	fmt.Println("hello world")
}
